package com.example.victoravancada;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.util.Log;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class Car implements Runnable {
    private String name;
    protected float x, y;
    protected float size;
    protected Bitmap trackBitmap;
    private Bitmap carImage;
    private int carColor;
    protected Map<String, Integer> trackSensors;
    protected Map<String, Integer> carProximitySensors;
    protected float directionAngle;
    private boolean lapCounted = false;
    private int lapCounter = 0;
    protected int speed;
    protected int maxSpeed;
    protected boolean isRunning = true;
    protected boolean isPaused = false;
    private Random random;
    private List<Car> allCars;
    private long slowDownEndTime = 0;
    private int priority;

    // Configuração do grid
    protected static Semaphore[][] trackGrid;
    public static final int GRID_SIZE = 50;
    public static final int GRID_START_X = 650; // Início do grid na pista
    public static final int GRID_END_X = 750;  // Fim do grid na pista
    public static final int GRID_START_Y = 50; // Início do grid na pista
    public static final int GRID_END_Y = 150; // Fim do grid na pista
    public int currentGridX = -1;
    public int currentGridY = -1;

    public Car(String name, float x, float y, float size, Bitmap trackBitmap, Bitmap carImage, int color, List<Car> allCars, Semaphore[][] grid) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.size = size;
        this.trackBitmap = trackBitmap;
        this.carImage = carImage;
        this.carColor = color;
        this.directionAngle = 180; // Movimento inicial para a esquerda
        this.trackSensors = new HashMap<>();
        this.carProximitySensors = new HashMap<>();
        this.random = new Random();
        this.maxSpeed = random.nextInt(51) + 200;
        this.speed = this.maxSpeed;
        this.allCars = allCars;
        trackGrid = grid;
        initSensors();
    }

    public String getName() {
        return name;
    }
    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public int getLapCounter() {
        return lapCounter;
    }

    public void incrementLapCounter() {
        lapCounter++;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public int getSpeed() {
        return speed;
    }

    public Bitmap getTintedCarImage() {
        return tintBitmap(carImage, carColor);
    }

    public float getDirectionAngle() {
        return directionAngle;
    }

    public int getColor() {
        return carColor;
    }

    public void stopRunning() {
        isRunning = false;
    }

    public void pauseRunning() {
        isPaused = true;
    }

    public void resumeRunning() {
        isPaused = false;
    }

    public void setSpeed(int speed) {
        this.speed = Math.min(speed, maxSpeed);
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    @Override
    public void run() {
        while (isRunning) {
            if (isPaused) {
                try {
                    Thread.sleep(50);
                    continue;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            move();
            updateSensors();
            detectObstacleAndAdjustSpeed();

            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void move() {
        int gridX = -1;
        int gridY = -1;

        Car safetyCar = findSafetyCar();
        Car carInFront = findCarInFront();

        int targetSpeed = maxSpeed;

        if (safetyCar != null && isNearSafetyCar(safetyCar)) {
            targetSpeed = Math.min(safetyCar.getSpeed() - 10, maxSpeed);
        } else if (carInFront != null) {
            double distanceToCarInFront = calculateDistanceTo(carInFront);

            if (distanceToCarInFront < 100 && carInFront.getSpeed() < this.speed) {
                targetSpeed = Math.max(carInFront.getSpeed() - 10, maxSpeed / 2);
            }
        }

        if (speed > targetSpeed) {
            speed -= 5;
        } else if (speed < targetSpeed) {
            speed += 5;
        }

        float radianAngle = (float) Math.toRadians(directionAngle);
        float nextX = x + (float) Math.cos(radianAngle) * (speed / 30.0f);
        float nextY = y + (float) Math.sin(radianAngle) * (speed / 30.0f);

        boolean inGridArea = nextX >= GRID_START_X && nextX <= GRID_END_X &&
                nextY >= GRID_START_Y && nextY <= GRID_END_Y;

        Log.d("MovimentoCarro", name + " movendo para (" + nextX + ", " + nextY + ")");

        if (inGridArea) {
            gridX = (int) ((nextX - GRID_START_X) / GRID_SIZE);
            gridY = (int) ((nextY - GRID_START_Y) / GRID_SIZE);

            if (gridX >= 0 && gridY >= 0 && gridX < trackGrid.length && gridY < trackGrid[0].length) {
                try {
                    // Libera o semáforo atual antes de adquirir o próximo
                    if (currentGridX != -1 && currentGridY != -1) {
                        trackGrid[currentGridX][currentGridY].release();
                        Log.d("MovimentoCarro", name + " liberou o grid (" + currentGridX + ", " + currentGridY + ")");
                    }

                    // Adquire o semáforo para a próxima célula
                    Log.d("MovimentoCarro", name + " tentando adquirir o grid (" + gridX + ", " + gridY + ")");
                    trackGrid[gridX][gridY].acquire();
                    Log.d("MovimentoCarro", name + " adquiriu o grid (" + gridX + ", " + gridY + ")");

                    // Atualiza a posição no grid
                    currentGridX = gridX;
                    currentGridY = gridY;

                    x = nextX;
                    y = nextY;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    Log.e("MovimentoCarro", name + " foi interrompido ao tentar adquirir o grid (" + gridX + ", " + gridY + ")");
                }
            } else {
                Log.e("MovimentoCarro", name + " calculou índices fora dos limites: (" + gridX + ", " + gridY + ")");
            }
        } else {
            x = nextX;
            y = nextY;

            // Libera o semáforo se o carro sai da área do grid
            if (currentGridX != -1 && currentGridY != -1) {
                try {
                    trackGrid[currentGridX][currentGridY].release();
                    Log.d("MovimentoCarro", name + " liberou o grid (" + currentGridX + ", " + currentGridY + ")");
                } catch (Exception e) {
                    Log.e("MovimentoCarro", name + " falhou ao liberar o grid (" + currentGridX + ", " + currentGridY + ")", e);
                }
                currentGridX = -1;
                currentGridY = -1;
            }
        }

        centralizeOnTrack();

        if (isNearStartingPoint()) {
            if (!lapCounted) {
                incrementLapCounter();
                lapCounted = true;
                Log.d("MovimentoCarro", name + " completou uma volta");
            }
        } else {
            lapCounted = false;
        }

        if (x < 0) x = 0;
        if (x > trackBitmap.getWidth() - size) x = trackBitmap.getWidth() - size;
        if (y < 0) y = 0;
        if (y > trackBitmap.getHeight() - size) y = trackBitmap.getHeight() - size;
        try {
            // Simula tentativa de adquirir semáforo em uma célula fora dos limites
            trackGrid[-1][-1].acquire(); // Isso causará ArrayIndexOutOfBoundsException
        }
        catch (ArrayIndexOutOfBoundsException | InterruptedException e) {
            Log.e("TesteErro", "Erro capturado: Tentativa de acessar celula invalida no grid.");
        }
    }
    public void setPriority(int priority) {
        if (priority < 1 || priority > 10) {
            throw new IllegalArgumentException("A prioridade deve estar entre 1 e 10.");
        }
        this.priority = priority;
    }

    // Método para obter a prioridade
    public int getPriority() {
        return this.priority;
    }

    public double calculateDistanceTo(Car otherCar) {
        return Math.sqrt(Math.pow(otherCar.getX() - this.x, 2) + Math.pow(otherCar.getY() - this.y, 2));
    }

    private float calculateAngleTo(Car otherCar) {
        float deltaX = otherCar.getX() - this.x;
        float deltaY = otherCar.getY() - this.y;
        float angleToOtherCar = (float) Math.toDegrees(Math.atan2(deltaY, deltaX));
        if (angleToOtherCar < 0) {
            angleToOtherCar += 360;
        }
        return angleToOtherCar;
    }

    private Car findCarInFront() {
        Car closestCar = null;
        double minDistance = Double.MAX_VALUE;

        for (Car car : allCars) {
            if (car != this) {
                double distance = calculateDistanceTo(car);
                float angleToCar = calculateAngleTo(car);

                if (distance < minDistance && Math.abs(angleToCar - directionAngle) < 30) {
                    closestCar = car;
                    minDistance = distance;
                }
            }
        }
        return closestCar;
    }

    public Car findSafetyCar() {
        for (Car car : allCars) {
            if (car instanceof SafetyCar) {
                return car;
            }
        }
        return null;
    }

    public boolean isNearOtherCar(Car otherCar) {
        double distance = calculateDistanceTo(otherCar);
        return distance < 100;
    }

    public boolean isNearSafetyCar(Car safetyCar) {
        double distance = Math.sqrt(Math.pow(safetyCar.getX() - this.x, 2) + Math.pow(safetyCar.getY() - this.y, 2));
        return distance < 100;
    }

    private void detectObstacleAndAdjustSpeed() {
        boolean shouldSlowDown = false;

        for (int sensorValue : trackSensors.values()) {
            if (sensorValue != Color.WHITE && sensorValue != Color.BLACK) {
                shouldSlowDown = true;
                break;
            }
        }

        for (int sensorValue : carProximitySensors.values()) {
            if (sensorValue != Color.WHITE && sensorValue != Color.BLACK) {
                shouldSlowDown = true;
                break;
            }
        }

        if (shouldSlowDown) {
            slowDownEndTime = System.currentTimeMillis() + 1000;
        }
    }

    public void updateSensors() {
        int sensorDistance = (int) (size + 60);

        trackSensors.put("front", readSensor((int) (x + Math.cos(Math.toRadians(directionAngle)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle)) * sensorDistance)));
        trackSensors.put("left", readSensor((int) (x + Math.cos(Math.toRadians(directionAngle - 60)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle - 60)) * sensorDistance)));
        trackSensors.put("right", readSensor((int) (x + Math.cos(Math.toRadians(directionAngle + 60)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle + 60)) * sensorDistance)));
        trackSensors.put("frontLeft", readSensor((int) (x + Math.cos(Math.toRadians(directionAngle - 45)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle - 45)) * sensorDistance)));
        trackSensors.put("frontRight", readSensor((int) (x + Math.cos(Math.toRadians(directionAngle + 45)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle + 45)) * sensorDistance)));

        carProximitySensors.put("front", detectCar((int) (x + Math.cos(Math.toRadians(directionAngle)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle)) * sensorDistance)));
        carProximitySensors.put("left", detectCar((int) (x + Math.cos(Math.toRadians(directionAngle - 60)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle - 60)) * sensorDistance)));
        carProximitySensors.put("right", detectCar((int) (x + Math.cos(Math.toRadians(directionAngle + 60)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle + 60)) * sensorDistance)));
        carProximitySensors.put("frontLeft", detectCar((int) (x + Math.cos(Math.toRadians(directionAngle - 45)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle - 45)) * sensorDistance)));
        carProximitySensors.put("frontRight", detectCar((int) (x + Math.cos(Math.toRadians(directionAngle + 45)) * sensorDistance),
                (int) (y + Math.sin(Math.toRadians(directionAngle + 45)) * sensorDistance)));
    }

    private int readSensor(int x, int y) {
        if (x >= 0 && x < trackBitmap.getWidth() && y >= 0 && y < trackBitmap.getHeight()) {
            int pixelColor = trackBitmap.getPixel(x, y);
            return pixelColor;
        }
        return Color.BLACK;
    }

    private int detectCar(int x, int y) {
        if (x >= 0 && x < trackBitmap.getWidth() && y >= 0 && y < trackBitmap.getHeight()) {
            int pixelColor = trackBitmap.getPixel(x, y);
            return (pixelColor != Color.WHITE && pixelColor != Color.BLACK) ? pixelColor : Color.WHITE;
        }
        return Color.WHITE;
    }

    private void initSensors() {
        trackSensors.put("front", Color.WHITE);
        trackSensors.put("left", Color.WHITE);
        trackSensors.put("right", Color.WHITE);
        trackSensors.put("frontLeft", Color.WHITE);
        trackSensors.put("frontRight", Color.WHITE);

        carProximitySensors.put("front", Color.WHITE);
        carProximitySensors.put("left", Color.WHITE);
        carProximitySensors.put("right", Color.WHITE);
        carProximitySensors.put("frontLeft", Color.WHITE);
        carProximitySensors.put("frontRight", Color.WHITE);
    }

    private void centralizeOnTrack() {
        if (trackSensors.get("left") != null && trackSensors.get("left") != Color.WHITE) {
            directionAngle += 3.0f;
        } else if (trackSensors.get("right") != null && trackSensors.get("right") != Color.WHITE) {
            directionAngle -= 3.0f;
        }

        if (trackSensors.get("frontLeft") != null && trackSensors.get("frontLeft") != Color.WHITE) {
            directionAngle += 1.5f;
        } else if (trackSensors.get("frontRight") != null && trackSensors.get("frontRight") != Color.WHITE) {
            directionAngle -= 1.5f;
        }

        normalizeDirection();
    }

    protected void normalizeDirection() {
        if (directionAngle >= 360) {
            directionAngle -= 360;
        } else if (directionAngle < 0) {
            directionAngle += 360;
        }
    }

    private boolean isNearStartingPoint() {
        return Math.abs(x - 700) < 50 && Math.abs(y - 100) < 50;
    }

    private Bitmap tintBitmap(Bitmap bitmap, int color) {
        Bitmap tintedBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        Canvas canvas = new Canvas(tintedBitmap);
        Paint paint = new Paint();
        paint.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, 0, 0, paint);
        return tintedBitmap;
    }
}