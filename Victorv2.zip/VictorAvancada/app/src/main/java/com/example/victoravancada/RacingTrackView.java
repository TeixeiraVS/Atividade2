package com.example.victoravancada;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.util.AttributeSet;
import android.view.View;
import java.util.List;

public class RacingTrackView extends View {

    private List<Car> cars;
    private Bitmap trackBitmap;

    public RacingTrackView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
        invalidate();
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setTrackBitmap(Bitmap trackBitmap) {
        this.trackBitmap = trackBitmap;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (trackBitmap != null) {
            canvas.drawBitmap(trackBitmap, 0, 0, null);
        }

        if (cars != null && !cars.isEmpty()) {
            for (Car car : cars) {
                Bitmap tintedCarImage = car.getTintedCarImage();
                if (tintedCarImage != null) {
                    Matrix matrix = new Matrix();
                    matrix.postTranslate(-tintedCarImage.getWidth() / 2f, -tintedCarImage.getHeight() / 2f);
                    matrix.postRotate(car.getDirectionAngle());
                    matrix.postTranslate(car.getX(), car.getY());

                    canvas.drawBitmap(tintedCarImage, matrix, null);
                }
            }
        }
    }
}