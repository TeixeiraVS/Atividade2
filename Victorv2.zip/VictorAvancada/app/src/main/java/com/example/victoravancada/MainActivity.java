package com.example.victoravancada;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;

import com.google.firebase.Firebase;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class MainActivity extends AppCompatActivity {

    private RacingTrackView racingTrackView;
    private Bitmap trackBitmap;
    private Button startButton, endButton, pauseButton, safetyCarButton;
    private EditText numberOfCarsInput;
    private LinearLayout lapCounterContainer;
    private boolean isMoving = false;
    private boolean isPaused = false;
    private int numberOfCars = 3;
    private Map<String, TextView> carLapTextViews = new HashMap<>();
    private Handler handler = new Handler();
    private List<Car> carsList;
    private SafetyCar safetyCar;
    private boolean isSafetyCarActive = false;

    // Configuração do grid de semáforos
    private static final int GRID_START_X = 680; // Coordenada inicial X
    private static final int GRID_END_X = 720;  // Coordenada final X
    private static final int GRID_START_Y = 80; // Coordenada inicial Y
    private static final int GRID_END_Y = 120; // Coordenada final Y
    private static final int GRID_SIZE = 20;   // Tamanho de cada célula do grid
    private Semaphore[][] trackGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        racingTrackView = findViewById(R.id.RacingTrackView);
        trackBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.pista);
        racingTrackView.setTrackBitmap(trackBitmap);
        racingTrackView.invalidate();

        lapCounterContainer = findViewById(R.id.lapCounterContainer);
        numberOfCarsInput = findViewById(R.id.numberOfCarsInput);

        startButton = findViewById(R.id.startButton);
        pauseButton = findViewById(R.id.pauseButton);
        endButton = findViewById(R.id.endButton);
        safetyCarButton = findViewById(R.id.safetyCarButton);

        startButton.setOnClickListener(v -> {
            if (!isMoving) {
                loadCarStatus(); // Tente carregar os carros do Firestore
                if (carsList == null || carsList.isEmpty()) {
                    // Se não houver carros carregados, crie novos carros
                    String inputText = numberOfCarsInput.getText().toString();
                    if (!inputText.isEmpty()) {
                        numberOfCars = Integer.parseInt(inputText);
                    }
                    trackGrid = createTrackGrid();
                    carsList = createCars(numberOfCars);
                }
                racingTrackView.setCars(carsList); // Atualize a visualização com os carros carregados/criados
                setupLapCounters(carsList);
                startCarMovement();
                isMoving = true;
            }
        });


        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePauseResume();
                saveCarStatus(carsList);
            }
        });

        endButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopCarMovement();
                saveCarStatus(carsList);
                Toast.makeText(MainActivity.this, "Corrida finalizada!", Toast.LENGTH_LONG).show();
            }
        });

        safetyCarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSafetyCarActive) {
                    deactivateSafetyCar();
                } else {
                    activateSafetyCar();
                }
                isSafetyCarActive = !isSafetyCarActive;
                safetyCarButton.setText(isSafetyCarActive ? "Desativar Safety Car" : "Ativar Safety Car");
            }
        });
    }

    private void saveCarStatus(List<Car> cars) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        for (Car car : cars) {
            Map<String, Object> carData = new HashMap<>();
            carData.put("x", car.getX());
            carData.put("y", car.getY());
            carData.put("directionAngle", car.getDirectionAngle());
            carData.put("speed", car.getSpeed());
            carData.put("maxSpeed", car.getMaxSpeed());
            carData.put("lapCounter", car.getLapCounter());
            carData.put("color", String.format("#%06X", (0xFFFFFF & car.getColor())));

            // Salva no Firestore com o nome do carro como ID
            db.collection("cars").document(car.getName()).set(carData)
                    .addOnSuccessListener(aVoid -> Log.d("Firestore", "Carro " + car.getName() + " salvo com sucesso."))
                    .addOnFailureListener(e -> Log.e("Firestore", "Erro ao salvar carro: " + car.getName(), e));
        }
    }

    private void loadCarStatus() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("cars").get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        if (!task.getResult().isEmpty()) {
                            carsList.clear(); // Limpa apenas se houver novos dados
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                // Carregue os dados do Firestore
                                String name = document.getId();
                                float x = document.getDouble("x").floatValue();
                                float y = document.getDouble("y").floatValue();
                                float directionAngle = document.getDouble("directionAngle").floatValue();
                                int speed = document.getLong("speed").intValue();
                                int maxSpeed = document.getLong("maxSpeed").intValue();
                                int lapCounter = document.getLong("lapCounter").intValue();
                                int color = Color.parseColor(document.getString("color"));

                                Bitmap carImage = BitmapFactory.decodeResource(getResources(), R.drawable.car_icon);
                                Car car = new Car(name, x, y, 25, trackBitmap, carImage, color, carsList, trackGrid);
                                car.setSpeed(speed);
                                car.setMaxSpeed(maxSpeed);
                                car.directionAngle = directionAngle;
                                for (int i = 0; i < lapCounter; i++) {
                                    car.incrementLapCounter();
                                }
                                carsList.add(car);
                            }
                            racingTrackView.setCars(carsList);
                            racingTrackView.invalidate();
                            Log.d("Firestore", "Carros carregados com sucesso.");
                        } else {
                            Log.d("Firestore", "Nenhum carro encontrado no Firestore.");
                        }
                    } else {
                        Log.e("Firestore", "Erro ao carregar carros", task.getException());
                    }
                });
    }



    /**
     * Cria o grid de semáforos para a região delimitada.
     */
    private Semaphore[][] createTrackGrid() {
        int rows = (int) Math.ceil((double) (GRID_END_Y - GRID_START_Y) / GRID_SIZE);
        int cols = (int) Math.ceil((double) (GRID_END_X - GRID_START_X) / GRID_SIZE);
        Semaphore[][] grid = new Semaphore[cols][rows];

        for (int i = 0; i < cols; i++) {
            for (int j = 0; j < rows; j++) {
                grid[i][j] = new Semaphore(1); // Apenas um carro por célula
            }
        }
        return grid;
    }

    /**
     * Cria os carros da corrida.
     */
    private List<Car> createCars(int numberOfCars) {
        int carSize = 25;
        int initialX = 700;
        int initialY = 100;
        int xOffset = 120;

        List<Car> carsList = new ArrayList<>();
        for (int i = 0; i < numberOfCars; i++) {
            int color = generateRandomColor();
            Bitmap carImage = BitmapFactory.decodeResource(getResources(), R.drawable.car_icon);

            int posX = initialX + i * xOffset;
            int posY = initialY;

            // Passa o grid para cada carro
            Car car = new Car("Carro" + (i + 1), posX, posY, carSize, trackBitmap, carImage, color, carsList, trackGrid);
            carsList.add(car);
        }
        return carsList;
    }

    /**
     * Configura os contadores de voltas para exibir na interface.
     */
    private void setupLapCounters(List<Car> carsList) {
        lapCounterContainer.removeAllViews();
        carLapTextViews.clear();

        for (Car car : carsList) {
            TextView lapTextView = new TextView(this);
            lapTextView.setText(car.getName() + " - Voltas: 0");
            lapCounterContainer.addView(lapTextView);
            carLapTextViews.put(car.getName(), lapTextView);
        }
    }

    /**
     * Inicia o movimento dos carros.
     */
    private void startCarMovement() {
        for (Car car : carsList) {
            Thread carThread = new Thread(car);
            carThread.start();
        }

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateLapCounters();
                racingTrackView.invalidate();
                if (isMoving) {
                    handler.postDelayed(this, 50);
                }
            }
        }, 50);
    }

    /**
     * Atualiza os contadores de voltas dos carros na interface.
     */
    private void updateLapCounters() {
        for (Car car : carsList) {
            TextView lapTextView = carLapTextViews.get(car.getName());
            if (lapTextView != null) {
                lapTextView.setText(car.getName() + " - Voltas: " + car.getLapCounter());
            }
        }
    }

    /**
     * Para o movimento dos carros.
     */
    private void stopCarMovement() {
        isMoving = false;
        for (Car car : carsList) {
            car.stopRunning();
        }
    }

    /**
     * Alterna entre pausar e retomar a corrida.
     */
    private void togglePauseResume() {
        if (isPaused) {
            for (Car car : carsList) {
                car.resumeRunning();
            }
            pauseButton.setText("Pausar");
            isPaused = false;
        } else {
            for (Car car : carsList) {
                car.pauseRunning();
            }
            pauseButton.setText("Retomar");
            isPaused = true;
        }
    }

    /**
     * Gera uma cor aleatória para os carros.
     */
    private int generateRandomColor() {
        int[] colors = {0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFFFFFF00, 0xFF00FFFF};
        return colors[new Random().nextInt(colors.length)];
    }

    /**
     * Ativa o Safety Car na pista.
     */
    private void activateSafetyCar() {
        Bitmap carImage = BitmapFactory.decodeResource(getResources(), R.drawable.car_icon);
        safetyCar = new SafetyCar("Safety Car", 700, 100, 30, trackBitmap, carImage, Color.YELLOW, carsList, trackGrid);
        carsList.add(safetyCar);
        Thread safetyCarThread = new Thread(safetyCar);
        safetyCarThread.start();
    }

    /**
     * Desativa o Safety Car.
     */
    private void deactivateSafetyCar() {
        if (safetyCar != null) {
            safetyCar.stopRunning();
            carsList.remove(safetyCar);
            safetyCar = null;
        }
    }
}